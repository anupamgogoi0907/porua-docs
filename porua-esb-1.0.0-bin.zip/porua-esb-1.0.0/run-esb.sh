#!/bin/bash

java  -Djava.rmi.server.hostname=127.0.0.1 \
-Dcom.sun.management.jmxremote.port=8855 \
-Dcom.sun.management.jmxremote.authenticate=false \
-Dcom.sun.management.jmxremote.ssl=false \
-jar porua-container-1.0.0.jar