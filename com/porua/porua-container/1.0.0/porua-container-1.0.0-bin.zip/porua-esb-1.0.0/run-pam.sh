#!/bin/bash

java -jar pam/porua-app-manager-1.0.0.jar