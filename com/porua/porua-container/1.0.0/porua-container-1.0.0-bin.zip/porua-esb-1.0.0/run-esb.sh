#!/bin/sh
set -x

JMX_PORT=8855
HOST="0.0.0.0"
JAR_FILE="porua-container-1.0.0.jar"


java \
-Dcom.sun.management.jmxremote.host=$HOST \
-Dcom.sun.management.jmxremote.port=$JMX_PORT \
-Djava.rmi.server.hostname=$HOST \
-Dcom.sun.management.jmxremote.rmi.port=$JMX_PORT \
-Dcom.sun.management.jmxremote.authenticate=false \
-Dcom.sun.management.jmxremote.ssl=false \
-jar $JAR_FILE